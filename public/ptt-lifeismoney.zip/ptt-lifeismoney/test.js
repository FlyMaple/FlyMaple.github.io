const fetch = require('node-fetch');

fetch('https://api.line.me/v2/bot/message/push', {
	body: JSON.stringify({
		to: 'Ua00d2fb3eaf07c373d88b100c0006fb3',
		messages: [{
			type: 'text',
			text: 'Test'
		}]
	}),
	headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer 8YAyKC1qictaIWlyG5tv4grsp86kTdjqH8I1g0Sq3PqVryx3plZIwgEC4zhTaF2yjdzaFKbZzNb7R1lAkV2mixbPyHzNROp8brAGZ8je6gRNqMhcODehKyRASBBqI3wNKx2DdkSrxpkeR5YlnCmJWQdB04t89/1O/w1cDnyilFU='
    },
	method: 'POST',
	mode: 'no-cors',
})

// 標籤: #19390 - [Bug][New][Gating] - 國麟 黃
// 主旨: [Phase3][AP]當CC detect country is USA, 應該要can't change to another country
// 時間: 2018-03-15 09:24