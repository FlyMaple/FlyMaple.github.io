module.exports = {
    BASEURL: 'https://www.ptt.cc/',
    SENDER: {
        EMAIL: 'kaithwu2016@gmail.com',
        PASSWORD: 'qpwoEIRUty'
    },
    RECIPIENT: 'Ua00d2fb3eaf07c373d88b100c0006fb3',
    SUBSCRIPTIONS: [
        {
            title: 'LifeIsMoney',
            path: 'bbs/lifeismoney',
            subject: '【PTT - LifeIsMoney】',
            keywords: ['情報', '省錢'],
            storage: []
        }
    ]
};