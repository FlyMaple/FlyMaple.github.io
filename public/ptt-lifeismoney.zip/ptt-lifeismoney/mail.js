/** LIB */
var nodemailer = require('nodemailer');

/** CONFIG */
var CONFIG = require('./config');

/** Function */
function sendMail(subject, body) {
    var transporter = nodemailer.createTransport({
        service: 'Gmail',
        auth: {
            user: CONFIG.SENDER.EMAIL,
            pass: CONFIG.SENDER.PASSWORD
        }
    });

    var options = {
        //寄件者
        from: CONFIG.SENDER.EMAIL,
        //收件者
        to: CONFIG.RECIPIENT,
        //主旨
        text: subject,
        //主旨
        subject: subject,
        //嵌入 html 的內文
        html: body 
    };

    transporter.sendMail(options, function(error, info){
        if(error){
            console.log(error);
        }else{
            console.log('訊息發送: ' + subject);
        }
    });
}

module.exports.sendMail = sendMail;