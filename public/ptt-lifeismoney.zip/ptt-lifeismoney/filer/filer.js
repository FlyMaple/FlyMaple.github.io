const fs = require('fs');

class Filer {
    constructor() {
    }

    write(filepath, filename, data, encoded = 'utf8') {
        fs.writeFile(`${filepath}${filename}`, JSON.stringify(data, null, 4), encoded, () => {
        });
    }

    read(filepath, filename, encoded = 'utf-8') {
        JSON.parse(fs.readFileSync(`${filepath}${filename}`, 'utf-8'))
    }
}

module.exports = Filer;