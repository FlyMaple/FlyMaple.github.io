module.exports = {
  level: 'info',
  debug: function (message) {
    if (this.level === 'debug') {
      console.log('Debug:');
      console.log(message);
    }
  },
  log: function (message) {
    console.log(message);
  }
}