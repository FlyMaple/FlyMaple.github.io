const EventEmitter = require('events');
const fetch = require('node-fetch');
const http = require('http');
const crypto = require('crypto');
const bodyParser = require('body-parser');
const logger = require('../logger');

class LineBot extends EventEmitter {
  /* EVENT TYPE */
  static get EVENT_TYPE_MESSAGE() { return 'message'; };
  static get EVENT_TYPE_POSTBACK() { return 'postback'; };

  /* SOURCE TYPE */
  static get SOURCE_TYPE_GROUP() { return 'group' };
  static get SOURCE_TYPE_ROOM() { return 'room' };

  /* MESSAGE TYPE */
  static get MESSAGE_TYPE_TEXT() { return 'text'; };
  static get MESSAGE_TYPE_AUDIO() { return 'audio'; };
  static get MESSAGE_TYPE_VIDEO() { return 'video'; };
  static get MESSAGE_TYPE_IMAGE() { return 'image'; };
  static get MESSAGE_TYPE_LOCATION() { return 'location'; };
  static get MESSAGE_TYPE_STICKER() { return 'sticker'; };
  static get MESSAGE_TYPE_IMAGEMAP() { return 'imagemap'; };
  static get MESSAGE_TYPE_TEMPLATE() { return 'template'; };

  /* Combine EVENT TYPE and MESSAGE TYPE */
  static get MESSAGE_TEXT() { return LineBot.EVENT_TYPE_MESSAGE + '.' + LineBot.MESSAGE_TYPE_TEXT; };
  static get MESSAGE_AUDIO() { return LineBot.EVENT_TYPE_MESSAGE + '.' + LineBot.MESSAGE_TYPE_AUDIO; };
  static get MESSAGE_VIDEO() { return LineBot.EVENT_TYPE_MESSAGE + '.' + LineBot.MESSAGE_TYPE_VIDEO; };
  static get MESSAGE_IMAGE() { return LineBot.EVENT_TYPE_MESSAGE + '.' + LineBot.MESSAGE_TYPE_IMAGE; };
  static get MESSAGE_LOCATION() { return LineBot.EVENT_TYPE_MESSAGE + '.' + LineBot.MESSAGE_TYPE_LOCATION; };
  static get MESSAGE_STICKER() { return LineBot.EVENT_TYPE_MESSAGE + '.' + LineBot.MESSAGE_TYPE_STICKER; };
  static get MESSAGE_IMAGEMAP() { return LineBot.EVENT_TYPE_MESSAGE + '.' + LineBot.MESSAGE_TYPE_IMAGEMAP; };
  static get MESSAGE_TEMPLATE() { return LineBot.EVENT_TYPE_MESSAGE + '.' + LineBot.MESSAGE_TYPE_TEMPLATE; };

  constructor(options) {
    super();

    this.options = options || {};
    this.channelId = this.options.channelId || '';
    this.channelSecret = this.options.channelSecret || '';
    this.channelAccessToken = this.options.channelAccessToken || '';

    this.headers = {
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + this.channelAccessToken
    };

    this.apiPath = 'https://api.line.me/v2/bot';
  }

  /*****************************************************
   * 
   * fetch 封裝
   * 
   *****************************************************/

  post(path, body) {
    return fetch(this.apiPath + path, {
      method: 'POST',
      headers: this.headers,
      body: JSON.stringify(body)
    }).then(res => {
      return {
        statusCode: res.status,
        statusText: res.statusText,
        messagePromise: res.json()
      }
    });
  }

  get(path) {
    return fetch(this.apiPath + path, {
      method: 'GET',
      headers: this.headers
    }).then(res => {
      return {
        statusCode: res.status,
        statusText: res.statusText,
        messagePromise: res.json()
      }
    });
  }

  /*****************************************************
   * 
   * 雜項 API
   * 
   *****************************************************/

  getProfile(userId) {
    return this.get('/profile/' + userId);
  }

  leave(id) {
    return this.post('/group/' + id + '/leave');
  }

  /*****************************************************
   * 
   * 被動回復 API
   * 
   *****************************************************/

  injectReply(event) {
    event.replyText = (replyMessage) => {
      return this.reply({
        replyToken: event.replyToken,
        messages: this.createTextMessage(replyMessage)
      });
    }

    event.replyImage = (originalContentUrl, previewImageUrl) => {
      return this.reply({
        replyToken: event.replyToken,
        messages: this.createImageMessage(originalContentUrl, previewImageUrl)
      });
    }

    event.replyVideo = (originalContentUrl, previewImageUrl) => {
      return this.reply({
        replyToken: event.replyToken,
        messages: this.createVideoMessage(originalContentUrl, previewImageUrl)
      });
    }

    event.replyAudio = (originalContentUrl, duration) => {
      return this.reply({
        replyToken: event.replyToken,
        messages: this.createAudioMessage(originalContentUrl, duration)
      });
    }

    event.replyLocation = (title, address, latitude, longitude) => {
      return this.reply({
        replyToken: event.replyToken,
        messages: this.createLocationMessage(title, address, latitude, longitude)
      });
    }

    event.replySticker = (packageId, stickerId) => {
      return this.reply({
        replyToken: event.replyToken,
        messages: this.createStickerMessage(packageId, stickerId)
      });
    }

    event.replyImageMap = (imageMap) => {
      return this.reply({
        replyToken: event.replyToken,
        messages: this.createImageMapMessage(imageMap)
      });
    }

    event.replyTemplate = (template) => {
      return this.reply({
        replyToken: event.replyToken,
        messages: this.createTemplateMessage(template)
      });
    }
  }

  reply(body) {
    return this.post('/message/reply', body);
  }

  /*****************************************************
   * 
   * 主動通知 API
   * 
   *****************************************************/

  //  TODO: 暫不啟用，未實作完成
  // multicast(userIds, message) {
  //   if (Array.isArray(userIds)) {
  //     return this.post('/message/multicast', {
  //       to: userIds,
  //       messages: [{ type: 'text', text: message }, { type: 'text', text: message }]
  //     });
  //   } else {
  //     logger.log('-- userIds is not Array --');
  //   }
  // }

  push(body) {
    return this.post('/message/push', body);
  }

  sendText(userId, messages) {
    return this.push({
      to: userId,
      messages: this.createTextMessage(messages)
    });
  }

  sendImage(userId, originalContentUrl, previewImageUrl) {
    return this.push({
      to: userId,
      messages: this.createImageMessage(originalContentUrl, previewImageUrl)
    });
  }

  sendVideo(userId, originalContentUrl, previewImageUrl) {
    return this.push({
      to: userId,
      messages: this.createVideoMessage(originalContentUrl, previewImageUrl)
    });
  }

  sendAudio(userId, originalContentUrl, duration) {
    return this.push({
      to: userId,
      messages: this.createAudioMessage(originalContentUrl, duration)
    });
  }

  sendLocation(userId, title, address, latitude, longitude) {
    return this.push({
      to: userId,
      messages: this.createLocationMessage(title, address, latitude, longitude)
    });
  }

  sendSticker(userId, packageId, stickerId) {
    return this.push({
      to: userId,
      messages: this.createStickerMessage(packageId, stickerId)
    });
  }

  sendImageMap(userId, imageMap) {
    return this.push({
      to: userId,
      messages: this.createImageMapMessage(imageMap)
    });
  }

  sendTemplate(userId, template) {
    return this.push({
      to: userId,
      messages: this.createTemplateMessage(template)
    });
  }

  /*****************************************************
   * 
   * 建立 Push Message 的物件
   * 
   *****************************************************/

  createTextMessage(messages) {
    if (Array.isArray(messages)) {
      return messages.map(message => {
        return {
          type: LineBot.MESSAGE_TYPE_TEXT,
          text: message
        }
      });
    } else {
      return [{ type: LineBot.MESSAGE_TYPE_TEXT, text: messages }];
    }
  }

  createImageMessage(param1, param2) {
    let originalContentUrl;
    let previewImageUrl;

    if (typeof param1 === 'string' && typeof param2 === 'string') {
      originalContentUrl = param1;
      previewImageUrl = param2;
    } else if (typeof param1 === 'string' && typeof param2 === 'undefined') {
      originalContentUrl = param1;
      previewImageUrl = param1;
    } else if (Array.isArray(param1)) {
      return param1.map(message => {
        return {
          type: LineBot.MESSAGE_TYPE_IMAGE,
          originalContentUrl: message.originalContentUrl,
          previewImageUrl: message.previewImageUrl
        };
      });
    }

    return [{
      type: LineBot.MESSAGE_TYPE_IMAGE,
      originalContentUrl,
      previewImageUrl
    }];
  }

  createVideoMessage(param1, param2) {
    let originalContentUrl;
    let previewImageUrl;

    if (typeof param1 === 'string' && typeof param2 === 'string') {
      originalContentUrl = param1;
      previewImageUrl = param2;
    } else if (typeof param1 === 'string' && typeof param2 === 'undefined') {
      logger.log('-- video is miss previewImageUrl --');

      return;
    } else if (Array.isArray(param1)) {
      return param1.map(message => {
        return {
          type: LineBot.MESSAGE_TYPE_VIDEO,
          originalContentUrl: message.originalContentUrl,
          previewImageUrl: message.previewImageUrl
        };
      });
    }

    return [{
      type: LineBot.MESSAGE_TYPE_VIDEO,
      originalContentUrl,
      previewImageUrl
    }];
  }

  createAudioMessage(param1, param2) {
    let originalContentUrl;
    let duration;

    if (typeof param1 === 'string' && typeof param2 === 'number') {
      originalContentUrl = param1;
      duration = param2;
    } else if (typeof param1 === 'string' && typeof param2 === 'undefined') {
      logger.log('-- audio is miss duration --');

      return;
    } else if (Array.isArray(param1)) {
      return param1.map(message => {
        return {
          type: LineBot.MESSAGE_TYPE_AUDIO,
          originalContentUrl: message.originalContentUrl,
          duration: message.duration
        };
      });
    }

    return [{
      type: LineBot.MESSAGE_TYPE_AUDIO,
      originalContentUrl,
      duration
    }];
  }

  createLocationMessage(param1, param2, param3, param4) {
    let title;
    let address;
    let latitude;
    let longitude;

    if (typeof param1 === 'string') {
      title = param1;
      address = param2;
      latitude = param3;
      longitude = param4;
    } else if (Array.isArray(param1)) {
      return param1.map(message => {
        return {
          type: LineBot.MESSAGE_TYPE_LOCATION,
          title: message.title,
          address: message.address,
          latitude: message.latitude,
          longitude: message.longitude
        };
      });
    }

    return [{
      type: LineBot.MESSAGE_TYPE_LOCATION,
      title: param1,
      address: param2,
      latitude: param3,
      longitude: param4
    }];
  }

  createStickerMessage(param1, param2) {
    let packageId;
    let stickerId;

    if (typeof param1 === 'string') {
      packageId = param1;
      stickerId = param2;
    } else if (Array.isArray(param1)) {
      return param1.map(message => {
        return {
          type: LineBot.MESSAGE_TYPE_STICKER,
          packageId: message.packageId,
          stickerId: message.stickerId
        };
      });
    }

    return [{
      type: LineBot.MESSAGE_TYPE_STICKER,
      packageId: param1,
      stickerId: param2
    }];
  }

  createImageMapMessage(imageMap) {
    imageMap.type = LineBot.MESSAGE_TYPE_IMAGEMAP;
    return [imageMap];
  }

  createTemplateMessage(template) {
    template.type = LineBot.MESSAGE_TYPE_TEMPLATE;
    return [template];
  }

  /*****************************************************
   * 
   * 1. 接收 request
   * 2. 驗證 header: X-Line-Signature
   * 3. emit 分析後的訊息種類
   * 
   *****************************************************/

  //  驗證 request header X-Line-Signature
  verify(rawBody, signature) {
    const hash = crypto.createHmac('sha256', this.options.channelSecret)
      .update(rawBody, 'utf8')
      .digest('base64');

    return hash === signature;
  }

  //  emit 分析後的訊息種類
  parse(body) {
    if (!body || !body.events) {
      return;
    }

    body.events.forEach(event => {
      let eventType;

      if (LineBot.EVENT_TYPE_MESSAGE === event.type) {
        eventType = event.type + '.' + event.message.type;
      } else if (LineBot.EVENT_TYPE_POSTBACK === event.type) {
        eventType = LineBot.EVENT_TYPE_POSTBACK;
      }

      this.injectReply(event);

      process.nextTick(() => {
        this.emit(eventType, event);
      });
    });
  }

  //  接收 request
  parser() {
    const parser = bodyParser.json({
      verify: function (req, res, buf, encoding) {
        req.rawBody = buf.toString(encoding);
      }
    });

    return (req, res) => {
      parser(req, res, () => {
        const signature = req.get('X-Line-Signature');

        if (this.verify(req.rawBody, signature)) {
          logger.debug('verify success');

          this.parse(req.body);

          return res.send({});
        } else {
          logger.debug('verify error');

          return res.sendStatus(400);
        }
      });
    }
  }
}

module.exports = LineBot;