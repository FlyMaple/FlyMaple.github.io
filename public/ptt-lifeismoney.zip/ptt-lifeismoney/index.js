/** LIB */
var request = require('request');
var cheerio = require('cheerio');
var eventproxy = require('eventproxy');
var Mail = require('./mail');
var LineBot = require('./linebot');
var logger = require('./logger');

var bot = new LineBot({
    channelId: '1514593160',
    channelSecret: '3603917dff57b125660f452964c5a355',
    channelAccessToken: '8YAyKC1qictaIWlyG5tv4grsp86kTdjqH8I1g0Sq3PqVryx3plZIwgEC4zhTaF2yjdzaFKbZzNb7R1lAkV2mixbPyHzNROp8brAGZ8je6gRNqMhcODehKyRASBBqI3wNKx2DdkSrxpkeR5YlnCmJWQdB04t89/1O/w1cDnyilFU='
});


/** CONFIG */
var CONFIG = require('./config');

/** Function */
function getURL(path) {
    return CONFIG.BASEURL + path;
}

function keywordMatch(title, keywords) {
    var match = false;

    for (var i = 0; i < keywords.length; i++) {
        var keyword = keywords[i];

        if (title.indexOf(keyword) != -1) {
            match = true;
            break;
        }
    }

    return match;
}

function mailBodyFormat(body, url) {
    try {
        var $ = cheerio.load(body);
        var $content = $('#main-content');
    } catch (e) {
        console.log(e);
        console.log(body);
        return body;
    }

    return '<a href="' + url + '">點我開啟網頁</a><br><pre>' + $content.text() + '</pre>';
}

function init() {
    //  初始化動作 + 並行一次反饋處理
    ep.after('init', CONFIG.SUBSCRIPTIONS.length, function (data) {
        console.log('====== 啟動 ======');
        data.forEach(function (ss) {
            var last_article = ss.storage[ss.storage.length - 1];
            var url = getURL(last_article.link);

            request(url, function (err, res, body) {
                // ss.storage.splice(ss.storage.length - 1, 1);    //  刪除最後一個做測試
                //  每個版都會寄一封信，確保啟動成功
                // Mail.sendMail(ss.subject + '啟動確認', mailBodyFormat(body, url));
                bot.sendText(CONFIG.RECIPIENT, 'LifeIsMoney 啟動確認').then(res => {
                    responseHandle(res);
                });
                bot.sendText('Ua167e8bc8a112a5ca31b88eb7713b233', 'LifeIsMoney 啟動確認').then(res => {
                    responseHandle(res);
                });
            });
        });

        lanch = true;
    });

    run();
    setInterval(run, 1000 * 3);
}

function run() {
    var cheerioOptions = {
        normalizeWhitespace: true
    };

    //  對訂閱中的版做掃描
    CONFIG.SUBSCRIPTIONS.forEach(function (ss_item) {
        request(getURL(ss_item.path), function (err, res, body) {
            try {
                //  用 cheerio 進行分析
                if (body) {
                    var $ = cheerio.load(body, cheerioOptions);
                    var items = $('.r-ent');

                    //  對文章列表做分析
                    items.each(function (idx, rEnt) {
                        var title = $('.title', rEnt).text();
                        var link = $('.title a', rEnt).attr('href');
                        var date = $('.date', rEnt).text();
                        var author = $('.author', rEnt).text();

                        //  先進行關鍵字比對，true: 進行已存在資料比對
                        var match = keywordMatch(title, ss_item.keywords);
                        if (match) {
                            //  進行已存在資料比對
                            var isExist = ss_item.storage.find(function (elem, idx) {
                                return elem.title == title;
                            });

                            //  關鍵字成立 並且 尚未存在於storage中，就寄送通知
                            if (!isExist) {
                                if (lanch) {
                                    var url = getURL(link);
                                    request(getURL(link), function (err, res, body) {
                                        // Mail.sendMail(ss_item.subject + title, mailBodyFormat(body, url));
                                        bot.sendText(CONFIG.RECIPIENT, title + '\n' + url).then(res => {
                                            responseHandle(res);
                                        });
                                        bot.sendText('Ua167e8bc8a112a5ca31b88eb7713b233', title + '\n' + url).then(res => {
                                            responseHandle(res);
                                        });
                                    });
                                }

                                ss_item.storage.push({
                                    title: title,
                                    link: link,
                                    date: date,
                                    author: author
                                });
                            }
                        }
                    });

                    //  檢查storage 資料是否太多
                    checkStorage(ss_item.storage);

                    //  初始化判斷
                    if (!lanch) {
                        ep.emit('init', ss_item);
                    }
                }
            } catch (e) {
                console.log(e);
                console.log(body);
            }
        });
    });
}

function checkStorage(storage) {
    if (storage.length >= 30) {
        console.log('清除storage...');
        storage.splice(0, 10);
    }
}

/*****************************************************
 * 
 * response 處理
 * 
 *****************************************************/

function responseHandle(res) {
    if (res.statusCode === 200) {
        logger.debug('-- reply success --');
    } else {
        printErrorLog(res);
    }
}

function printErrorLog(res) {
    logger.log('-- call api error --');

    res.messagePromise.then(json => {
        logger.log(JSON.stringify({
            statusCode: res.statusCode,
            statusText: res.statusText,
            message: json
        }));
    });
}

/** MAIN */
var ep = new eventproxy();
var lanch = false;

init();