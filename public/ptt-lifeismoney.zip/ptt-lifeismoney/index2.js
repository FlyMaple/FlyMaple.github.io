var request = require('request');
var cheerio = require('cheerio');
var LineBot = require('./linebot');
const Filer = require('./filer');
const filer = new Filer();

var bot = new LineBot({
    channelId: '1514593160',
    channelSecret: '3603917dff57b125660f452964c5a355',
    channelAccessToken: '8YAyKC1qictaIWlyG5tv4grsp86kTdjqH8I1g0Sq3PqVryx3plZIwgEC4zhTaF2yjdzaFKbZzNb7R1lAkV2mixbPyHzNROp8brAGZ8je6gRNqMhcODehKyRASBBqI3wNKx2DdkSrxpkeR5YlnCmJWQdB04t89/1O/w1cDnyilFU='
});

const config = {
    BASEURL: 'https://www.ptt.cc/',
    PATHNAME: 'bbs/',
    RECIPIENTS: [
        'Ua00d2fb3eaf07c373d88b100c0006fb3',
        'Ua167e8bc8a112a5ca31b88eb7713b233'
    ],
    SUBSCRIPTIONS: [
        {
            name: 'LifeIsMoney',
            path: 'LifeIsMoney',
            keywords: [
                '情報', '省錢'
            ],
            excludes: ['公告'],
            storage: {},
        },
        {
            name: 'Gamesale',
            path: 'Gamesale',
            keywords: [
                'overcook'
            ],
            excludes: ['公告', 'ps', '徵', '一代', '1代', '[XONE'],
            storage: {},
        }
    ],
};

const keywordMatch = (title, keywords) => {
    let match = false;

    for (let i = 0; i < keywords.length; i++) {
        const keyword = keywords[i];

        if (title.toLowerCase().indexOf(keyword) != -1) {
            match = true;
            break;
        }
    }

    return match;
};

const cheerioLoad = (htmlBody) => {
    const options = {
        normalizeWhitespace: true,
    };

    return cheerio.load(htmlBody, options);
};

const getFilterArticleDict = (articlesDict, keywords, excludes) => {
    const dict = {};

    Object.keys(articlesDict).forEach(function (key) {
        const article = articlesDict[key];
        const title = article.title;

        if (keywordMatch(title, keywords)) {
            if (!keywordMatch(title, excludes)) {
                dict[article.key] = article;
            }
        }
    });

    return dict;
};

const getArticlesDict = (htmlBody) => {
    const $ = cheerioLoad(htmlBody);
    const $articles = $('.r-ent');
    const articlesDict = {};

    $articles.each((idx, rEnt) => {
        const title = $('.title', rEnt).text();
        const link = $('.title a', rEnt).attr('href');
        const keyPattern = /\/(M\.\w+\.\w+\.\w+)\.html/;

        if (!title) {
            // TODO: pattern no match notification
        } else if (!link) {
            // TODO: pattern no match notification
        } else if (link.match(keyPattern)) {
            const key = link.match(keyPattern)[1];

            articlesDict[key] = {
                title: title.trim(),
                link: link.substring(1, 99999),
                key,
            };
        } else {
            // TODO: pattern no match notification
        }
    });

    return articlesDict;
};

const getURL = (path) => {
    return `${config.BASEURL}${config.PATHNAME}${path}`;
}

const skRequest = (url, cb) => {
    return new Promise((resolve, reject) => {
        request(url, (err, resp, body) => {
            if (cb) {
                resolve(cb.call(null, err, resp, body));
            }

            if (resp && body) {
                resolve(Object.assign(resp, { err, body }));
            } else {
                // console.log(err);
                resolve();
            }
        });
    });
};

const getHtmlBody = async (url) => {
    return await skRequest(url).then(resp => {
        if (resp) {
            return resp.body;
        } else {
            return '';
        }
    });

};

const sendMessage = (recipients, message) => {
    recipients.forEach(userId => {
        bot.sendText(userId, message);
    });
    // console.log(message);
};

const run = () => {
    config.SUBSCRIPTIONS.forEach(async (subscribe, idx) => {
        const { path, name, storage } = subscribe;
        const htmlBody = await getHtmlBody(getURL(path));

        if (htmlBody) {
            const articlesDict = getArticlesDict(htmlBody);
            const articlesFilterDict = getFilterArticleDict(articlesDict, subscribe.keywords, subscribe.excludes);
    
            Object.keys(articlesFilterDict).forEach(key => {
                const articleOld = storage[key];
                const articleNew = articlesFilterDict[key];
    
                if (!articleOld) {
                    sendMessage(config.RECIPIENTS, `${articleNew.title}\n${config.BASEURL}${articleNew.link}`);
    
                    config.SUBSCRIPTIONS[idx]['storage'][key] = articleNew;
                }
            });
        }
    });
};

const init = async () => {
    const promises = [];

    config.SUBSCRIPTIONS.forEach((subscribe, idx) => {
        const p = new Promise(async (resolve, reject) => {
            const { path, name } = subscribe;
            const htmlBody = await getHtmlBody(getURL(path));

            if (htmlBody) {
                const articlesDict = getArticlesDict(htmlBody);
                const articlesFilterDict = getFilterArticleDict(articlesDict, subscribe.keywords, subscribe.excludes);
                // test 
                // delete articlesFilterDict['M.1534511761.A.5B3'];
                // console.log(articlesFilterDict);
                config.SUBSCRIPTIONS[idx]['storage'] = articlesFilterDict;
                console.log(`【初始化】 ${name}\t... done`);
    
                resolve();
            }
        });

        promises.push(p);
    });

    return Promise.all(promises).then(() => {
        sendMessage(config.RECIPIENTS, '呆寶 PTT 爬蟲啟動.');
    });
};

const main = async () => {
    await init();
    run();

    setInterval(run, 3 * 1000);
};

main();